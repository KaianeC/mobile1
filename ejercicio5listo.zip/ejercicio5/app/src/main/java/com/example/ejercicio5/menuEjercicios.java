package com.example.ejercicio5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class menuEjercicios extends AppCompatActivity implements View.OnClickListener {
    private Button frame;
    private Button linear;
    private Button relativa;
    private Button constraint;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_ejercicios);

        linear = findViewById(R.id.linearLayout);
        linear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent b = new Intent(getApplicationContext(),Ej5LinearLayout.class);
                startActivity(b);
            }
        });
        frame =  findViewById(R.id.frameLayout);
        frame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             Intent a = new Intent(getApplicationContext(),MainActivity.class);
             startActivity(a);
            }
        });

        relativa = findViewById(R.id.relativeLayout);
        relativa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent c = new Intent(getApplicationContext(),relativeLayout.class);
                startActivity(c);
            }
        });
        constraint= findViewById(R.id.constraintLayout);
        constraint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent d = new Intent(getApplicationContext(), contraintLayout.class);
                startActivity(d);
            }
        });
    }

    @Override
    public void onClick(View v) {

    }
}