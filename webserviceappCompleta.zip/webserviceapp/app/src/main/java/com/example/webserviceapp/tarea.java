package com.example.webserviceapp;

import android.os.AsyncTask;
import android.os.TokenWatcher;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

public class tarea extends AsyncTask<String, Void, String> {
    private TextView salida;
    public tarea(TextView salida){
        this.salida = salida;
    }
    @Override
    protected String doInBackground(String... strings) {
        StringBuffer str= new StringBuffer();
        try {
            URL direccion = new URL(strings[0]);
            HttpsURLConnection conexion = (HttpsURLConnection) direccion.openConnection();
            InputStream input = conexion.getInputStream();
            InputStreamReader reader = new InputStreamReader(input);
            BufferedReader lectura = new BufferedReader(reader);

            String aux;
            while((aux=lectura.readLine()) !=null){
                str.append(aux);
            }
            System.out.println(str.toString());
        }
        catch (MalformedURLException e){
            e.printStackTrace();
        }
        catch (IOException e){
            e.printStackTrace();
        }
        return str.toString();
    }

    @Override
    protected void onPostExecute(String s) {
        JSONObject i = null;
        try{
            i = new JSONObject(s);
            salida.setText(i.getString("name"));
        }catch (JSONException e){
            e.printStackTrace();
        }


        super.onPostExecute(s);
    }
}
