package com.example.webserviceapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText entrada;
    private TextView salida;
    private Button enviar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        entrada = (EditText) findViewById(R.id.entrada);
        salida= (TextView) findViewById(R.id.salida);
        enviar = (Button) findViewById(R.id.enviar);

        enviar.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.enviar){
            String url = "https://swapi.dev/api/people/" + entrada.getText().toString().trim();
            //conexion con internet
            // se crea otra clase que va a funcionar como thread y va a andar en paralelo con la main
            // se crea la clase llamada >
            tarea t = new tarea(salida);
            t.execute(url);
        }
    }
}