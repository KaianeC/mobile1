package com.example.introduccion2fragmentos;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Configuration;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Configuration config = getResources().getConfiguration();
    if (config.smallestScreenWidthDp<500) {
        ActionBar actionBar = getSupportActionBar();
        actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

        ActionBar.Tab tab1 = actionBar.newTab().setText("Tab 1");
        tab1.setTabListener(new MyTabListener(new Fragmento1()));
        actionBar.addTab(tab1);

        ActionBar.Tab tab2 = actionBar.newTab().setText("Tab 2");
        tab2.setTabListener(new MyTabListener(new Fragmento2()));
        actionBar.addTab(tab2);

        ActionBar.Tab tab3 = actionBar.newTab().setText("Tab 3");
        tab3.setTabListener(new MyTabListener(new Fragmento3()));
        actionBar.addTab(tab3);
        }
    }
}