package com.example.bibliotecaappp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.Serializable;
import java.util.List;

public class agregarLibroACT extends AppCompatActivity implements View.OnClickListener {
    private EditText etnombredb;
    private EditText etlinkdb;
    private Button btnenviarBD;
    //private Button btnmostrarBD;
    private libroDB db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_libro);
        etnombredb = findViewById(R.id.etnombredb);
        etlinkdb = findViewById(R.id.etlinkdb);
        btnenviarBD = findViewById(R.id.btnenviarBD);
        //btnmostrarBD = findViewById(R.id.btnmostrarBD);
        btnenviarBD.setOnClickListener(this);
    //    btnmostrarBD.setOnClickListener(this);
        db = new libroDB(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.btnenviarBD){
            libroE e = new libroE();
            e.setLibro(etnombredb.getText().toString().trim());
            e.setLink(etlinkdb.getText().toString().trim());
            db.save(e);
            Toast.makeText(this, "Nuevo Libro Añadido", Toast.LENGTH_SHORT).show();
            //codigo para guardar
        }
       /* else if(v.getId()==R.id.btnmostrarBD){
            //codigo para buscar
            List<libroE> l = db.findAll();
            for(int i=0; i<l.size(); i ++){
                //estudiante e =l.get(i);
                System.out.println(l.get(i).getId() + " - "+ l.get(i).getLibro()+ " - "+ l.get(i).getLink());
            }
            Intent i = new Intent(getApplicationContext(), librosACT.class);
            i.putExtra("objList", (Serializable) l);
            startActivity(i);
        }*/
    }
}