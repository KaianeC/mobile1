package com.example.bibliotecaappp;

import java.io.Serializable;

public class libroE implements Serializable {
    private int id;
    private String libro;
    private String link;

    public libroE(){
        this.id= 0;
        this.libro= "";
        this.link="";
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLibro() {
        return libro;
    }

    public void setLibro(String libro) {
        this.libro = libro;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
