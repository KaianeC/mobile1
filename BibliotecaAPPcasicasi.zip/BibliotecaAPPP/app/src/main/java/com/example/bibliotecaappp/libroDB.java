package com.example.bibliotecaappp;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class libroDB extends SQLiteOpenHelper {
    private static final String TAG = "sql";
    private static final String NOMBRE_BANCO = "libro.sqlite";
    private static final int VERSION  = 1;

    public libroDB(Context context){
        super(context, NOMBRE_BANCO, null, VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d(TAG, "Creando la tabla libro");

        db.execSQL("create table if not exists libro(id_ integer primary key autoincrement, libro text, link text);");

        Log.d(TAG, "tabla creada");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //no usamos.
    }
    public int delete(libroE e){
        SQLiteDatabase db =  getWritableDatabase();
        try {
            String iD =  String.valueOf(e.getId());
            String[] whereArgs = new String[]{iD};
            int count =db.delete("libro", "id_=?", whereArgs);
            return count;

        }catch (Exception ex){
            System.out.println( ex);
        }finally {
            db.close();
        }
        return 0;
    }

    @SuppressLint("Range")
    public List<libroE> toList(Cursor c){
        List<libroE> libroos = new ArrayList<>();
        if(c.moveToFirst()) {
            do {
                libroE e =  new libroE();
                e.setId(c.getInt(c.getColumnIndex("id_")));
                e.setLibro(c.getString(c.getColumnIndex("libro")));
                e.setLink(c.getString(c.getColumnIndex("link")));
                libroos.add(e);
            } while (c.moveToNext());
        }
        return libroos;
    }

    public List<libroE> findAll() {
        SQLiteDatabase db = getReadableDatabase();
        try{
            Cursor c = db.rawQuery("SELECT * FROM libro", null);
            return toList(c);
        }finally {

        }
        //return null;
    }

    public long save(libroE e){
        long id = e.getId();
        SQLiteDatabase db = getReadableDatabase();
        try{
            ContentValues values = new ContentValues();
            values.put("libro", e.getLibro());
            values.put("link", e.getLink());
            if (id != 0){
                //update
                String iD = String.valueOf(e.getId());
                String[] whereArgs = new String[]{iD};
                int count = db.update("libro", values, "id_ = ?",whereArgs);
                return count;
            }else{
                //insert
                id = db.insert("libro", "", values);
                return id;
            }
        }catch (Exception ex){
            System.out.println(ex);
        }finally {
            db.close();
        }
        return 0;
    }





}
