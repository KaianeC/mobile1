package com.example.bibliotecaappp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.List;

public class librosACT extends AppCompatActivity {
    private ListView lv;
    private libroDB db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_libros);
        getSupportActionBar().hide();
        ClipboardManager clipboardManager = (ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        lv = (ListView) findViewById(R.id.lv);

        List<libroE> lista = (List<libroE>) getIntent().getSerializableExtra("objList");

        String[] array = new String[lista.size()];
        String[] array2 = new String[lista.size()];
        for(int i=0 ;i<lista.size(); i++){
            array[i]= (String) lista.get(i).getLibro();
        }
        for(int i=0 ;i<lista.size(); i++){
            array2[i]= (String) lista.get(i).getLink();
        }
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,array);
        lv.setAdapter(adapter);
        final ArrayAdapter<String> adapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,array2);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String valor = adapter2.getItem(position);
                ClipData clipData = ClipData.newPlainText("label", valor);
                clipboardManager.setPrimaryClip(clipData);
                Toast.makeText(getApplicationContext(),"El link del libro ha sido copiado",Toast.LENGTH_LONG).show();
            }
        });
    }
}