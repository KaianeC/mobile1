package com.example.bibliotecaappp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class APIact extends AppCompatActivity implements View.OnClickListener  {
    private Button btnhora;
    private TextView tvhora;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apiact);
        tvhora = findViewById(R.id.salida);
        btnhora =  findViewById(R.id.btnhora);
        btnhora = findViewById(R.id.btnhora);
        btnhora.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String url = "https://www.timeapi.io/api/Time/current/coordinate?latitude=-32.522779&longitude=-55.765835";
        tarea a = new tarea(tvhora);
        a.execute(url);
    }
}