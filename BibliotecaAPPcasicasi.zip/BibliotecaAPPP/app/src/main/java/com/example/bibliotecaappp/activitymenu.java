package com.example.bibliotecaappp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import java.io.Serializable;
import java.util.List;

public class activitymenu extends AppCompatActivity implements View.OnClickListener {
    public Button btnlibros;
    public Button btnagregar;
    private libroDB db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activitymenu);
        btnlibros = findViewById(R.id.btnlibros);
        btnagregar = findViewById(R.id.btnagregar);
        btnagregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent j = new Intent(getApplicationContext(), agregarLibroACT.class);
                startActivity(j);
            }
        });
        btnlibros.setOnClickListener(this);

        db = new libroDB(this);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.itemAPIh) {
            Intent i = new Intent(getApplicationContext(), APIact.class);
            startActivity(i);
        }
        return true;

    }

    @Override
    public void onClick(View v) {
        List<libroE> l = db.findAll();
        for(int i=0; i<l.size(); i ++){
            //estudiante e =l.get(i);
            System.out.println(l.get(i).getId() + " - "+ l.get(i).getLibro()+ " - "+ l.get(i).getLink());
        }
        Intent i = new Intent(getApplicationContext(), librosACT.class);
        i.putExtra("objList", (Serializable) l);
        startActivity(i);
    }
}