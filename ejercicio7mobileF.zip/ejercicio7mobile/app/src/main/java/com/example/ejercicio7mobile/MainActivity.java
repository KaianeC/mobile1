package com.example.ejercicio7mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button btnbuscar;
    private Button btnguardar;
    private EditText nombre;
    private EditText curso;
    private estudianteBD db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnbuscar =  findViewById(R.id.buscar);
        btnguardar = findViewById(R.id.guardar);
        curso = findViewById(R.id.ecurso);
        nombre = findViewById(R.id.Enombre);

        btnguardar.setOnClickListener(this);
        btnbuscar.setOnClickListener(this);

        db = new estudianteBD(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.guardar){
            estudiante e = new estudiante();
            e.setNombre(nombre.getText().toString().trim());
            e.setCurso(curso.getText().toString().trim());
            db.save(e);
            //codigo para guardar
        }
        else if(v.getId()==R.id.buscar){
            //codigo para buscar
            List<estudiante> l =db.findAll();
            for(int i=0; i<l.size(); i ++){
                //estudiante e =l.get(i);
                System.out.println(l.get(i).getId() + " - "+ l.get(i).getNombre()+ " - "+ l.get(i).getCurso());
            }
        }
    }
}