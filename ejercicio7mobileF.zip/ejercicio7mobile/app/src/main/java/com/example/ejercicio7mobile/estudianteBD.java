package com.example.ejercicio7mobile;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.sql.Array;
import java.util.ArrayList;
import java.util.List;

public class estudianteBD extends SQLiteOpenHelper {
    private static final String TAG = "sql";
    private static final String NOMBRE_BANCO = "estudiante.sqlite";
    private static final int VERSION  = 1;

    public estudianteBD(Context context){
        super(context, NOMBRE_BANCO, null, VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d(TAG, "Creando la tabla estudiante");

        db.execSQL("create table if not exists estudiante(id_ integer primary key autoincrement, nombre text, curso text);");

        Log.d(TAG, "tabla creada");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //no usamos.
    }
    public int delete(estudiante e){
        SQLiteDatabase db =  getWritableDatabase();
        try {
            String iD =  String.valueOf(e.getId());
            String[] whereArgs = new String[]{iD};
            int count =db.delete("estudiante", "id_=?", whereArgs);
            return count;

        }catch (Exception ex){
            System.out.println( ex);
        }finally {
            db.close();
        }
        return 0;
    }

    @SuppressLint("Range")
    public List<estudiante> toList(Cursor c){
        List<estudiante> estudiantes = new ArrayList<>();
        if(c.moveToFirst()) {
            do {
                estudiante e =  new estudiante();
                e.setId(c.getInt(c.getColumnIndex("id_")));
                e.setNombre(c.getString(c.getColumnIndex("nombre")));
                e.setCurso(c.getString(c.getColumnIndex("curso")));
                estudiantes.add(e);
            } while (c.moveToNext());
        }
        return estudiantes;
    }


    public List<estudiante> findAll() {
        SQLiteDatabase db = getReadableDatabase();
        try{
            Cursor c = db.rawQuery("SELECT * FROM estudiante", null);
            return toList(c);
        }finally {

        }
        //return null;
    }
    public long save(estudiante e){
        long id = e.getId();
        SQLiteDatabase db = getReadableDatabase();
        try{
            ContentValues values = new ContentValues();
            values.put("nombre", e.getNombre());
            values.put("curso", e.getCurso());
            if (id != 0){
                //update
                String iD = String.valueOf(e.getId());
                String[] whereArgs = new String[]{iD};
                int count = db.update("estudiante", values, "id_ = ?",whereArgs);
                return count;
            }else{
                //insert
                id = db.insert("estudiante", "", values);
                return id;
            }
        }catch (Exception ex){
            System.out.println(ex);
        }finally {
            db.close();
        }
        return 0;
    }


}
