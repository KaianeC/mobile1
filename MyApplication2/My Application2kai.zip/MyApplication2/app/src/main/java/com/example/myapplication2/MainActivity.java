package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private EditText e1;
    private EditText e2;
    private EditText e3;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1= findViewById(R.id.nombre);
        e2= findViewById(R.id.contrasena);
        e3= findViewById(R.id.matricula);
        btn= findViewById(R.id.botonEnviar);

        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId()== R.id.botonEnviar) {
            String n;
            String c;
            String m;

            n = e1.getText().toString();
            c = e2.getText().toString();
            m = e3.getText().toString();
            String msg = "Usuario " + n + ", Contraseña " + c + ", matricula " + m;

            Toast.makeText(getApplicationContext(), msg, Toast.LENGTH_LONG).show();

        }
    }
}