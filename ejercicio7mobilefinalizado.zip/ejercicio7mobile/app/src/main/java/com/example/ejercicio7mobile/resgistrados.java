package com.example.ejercicio7mobile;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

public class resgistrados extends AppCompatActivity {
    private ListView lv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resgistrados);

        lv = (ListView) findViewById(R.id.lv);

        List<estudiante> lista = (List<estudiante>) getIntent().getSerializableExtra("objList");

        String[] array = new String[lista.size()];

        for(int i=0 ;i<lista.size(); i++){
            array[i]= (String) lista.get(i).getNombre()+" "+ lista.get(i).getCurso();
        }
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,array);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String valor = adapter.getItem(position);
                Toast.makeText(getApplicationContext(),valor,Toast.LENGTH_LONG).show();
            }
        });

    }
}